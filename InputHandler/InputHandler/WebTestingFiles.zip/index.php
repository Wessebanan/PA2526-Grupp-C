﻿<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>Lhures sida</title>

    <link rel="stylesheet" href="StyleSheet.css" />
    <script src="jquery-3.4.1.min.js"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

</head>
<body>

<main>
    <button id="test" onclick="myFunction()">Ping client</button>
    </br>
    <button id="add" onclick="AddClick()">Test for click</button>
    </br>
<?php include("generateButtons.php")?>

  <p id="JSONList"></p>
</main>
    <script type="text/javascript" src="scripts/script.js"></script>
    <script type="text/javascript" src="scripts/buttons.js"></script>

    <script type="text/javascript">



    </script>

</body>
</html>
